import {Routes, Route} from 'react-router-dom';
import Left from './component/left';
import Right from './component/right';
import Add from './pages/add';
import Home from './pages/home'
import Single from './pages/single';
import Test from './pages/test';
import './styles/main.scss'

const App = ()=>{
  return(
    <div className='App'>
      <Left/>
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/add" element={<Add/>} />
      <Route path="/test" element={<Test/>} />
      <Route path="/company/:id" element={<Single/>} />
    </Routes>
    <Right/>
    </div>
  )
}

export default App;