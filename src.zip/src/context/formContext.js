import {createContext, useContext, useState} from 'react'
import axios from 'axios'
export const formContext = createContext();

export const FormProvider = (props) => {

    //Framework and language data
    const lanData = [
        {language: "js"},
        {language: "python"},
        {language: "solidity"},
        {language: "c"}
    ]
    const frmData = [
        {frm: "react"},
        {frm: "django"},
        {frm: "dotnet"},
        {frm: "laravel"}
    ]

    //States
    const [formData, setFormData] = useState({}) 
    const [arrDisLan, setArrDisLan] = useState([]) //State to set language array
    const [arrDisFrm, setArrDisFrm] = useState([]) //State to set framework array    
    const [languageData] = useState(lanData); 
    const [frameworkData] = useState(frmData);

    //Handle Change function
    const handleChange = (e)=>{
        setFormData((prev) => {
            return(
                {...prev, [e.target.name] : e.target.value}
            )
        })
    }

    //Handle submit function
    const handleSubmit = (e)=>{
        e.preventDefault();
        const finalFormData = {
            ...formData,
            "language": arrDisLan,
            "framework": arrDisFrm
        }

        console.log(finalFormData)
        
        axios.post('http://localhost:8800/add', finalFormData)
        .then(()=>{
            console.log(formData)
        })
        .catch((error)=>{
            console.log(error)
        })
    }

    //Push framework and language data in array
    const arrayPushLan = (e)=>{
        const tempArr = []
        e.map((lan)=>{
            tempArr.push(lan.language)
        })
        setArrDisLan(tempArr)
    }
    const arrayPushFrm = (e)=>{
        const tempArr = []
        e.map((frm)=>{
            tempArr.push(frm.frm)
        })
        setArrDisFrm(tempArr)
    }
    

    //company context
    const [company, setCompany] = useState(undefined)
    
    return(
    <formContext.Provider value={{handleChange, handleSubmit, arrayPushLan, arrayPushFrm, languageData, frameworkData, company, setCompany}}>
        {props.children}
    </formContext.Provider>
    )
}