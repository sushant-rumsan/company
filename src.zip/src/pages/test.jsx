import { useContext } from "react";
import {formContext} from '../context/formContext'

const Test = () => {

    const {handleChange, test} = useContext(formContext)

    return ( 
        <div className="center">
            <h1 onClick={handleChange}>hello</h1>
        </div>
     );
}
 
export default Test;